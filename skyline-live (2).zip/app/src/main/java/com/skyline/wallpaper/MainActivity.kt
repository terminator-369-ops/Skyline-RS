package com.skyline.wallpaper

import android.Manifest
import android.app.Activity
import android.app.WallpaperManager
import android.content.ActivityNotFoundException
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Shader
import android.location.LocationManager
import android.os.Bundle
import android.os.SystemClock
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.*
import kotlin.math.min

class MainActivity : Activity() {
    private val cities = listOf(
        Triple("Delhi", 28.61, 77.21), Triple("Mumbai", 19.08, 72.88), Triple("Bengaluru", 12.97, 77.59),
        Triple("Kolkata", 22.57, 88.36), Triple("Chennai", 13.08, 80.27), Triple("Hyderabad", 17.39, 78.49),
        Triple("Paris", 48.86, 2.35), Triple("London", 51.51, -0.13), Triple("New York", 40.71, -74.01),
        Triple("Dubai", 25.20, 55.27), Triple("Tokyo", 35.68, 139.69), Triple("Sydney", -33.87, 151.21)
    )
    private lateinit var prefs: SharedPreferences
    private lateinit var info: TextView
    private lateinit var preview: ScenePreview

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        prefs = getSharedPreferences("scene", MODE_PRIVATE)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(40), dp(24), dp(32))
        }

        col.addView(TextView(this).apply { text = "Skyline Live"; textSize = 28f })
        info = TextView(this).apply { textSize = 15f; setPadding(0, dp(8), 0, dp(12)) }
        col.addView(info)

        // ---- Location ----
        val sp = Spinner(this)
        sp.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, listOf("Choose a city") + cities.map { it.first })
        sp.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(a: AdapterView<*>?, v: View?, i: Int, id: Long) {
                if (i > 0) save(cities[i - 1].second, cities[i - 1].third)
            }
            override fun onNothingSelected(a: AdapterView<*>?) {}
        }
        col.addView(sp)
        col.addView(Button(this).apply {
            text = "Use my location"
            setOnClickListener {
                if (checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED) useLocation()
                else requestPermissions(arrayOf(Manifest.permission.ACCESS_COARSE_LOCATION), 1)
            }
        })
        col.addView(CheckBox(this).apply {
            text = "Demo: 1 day = 2 minutes (sun and moon test)"
            isChecked = prefs.getBoolean("demo", false)
            setOnCheckedChangeListener { _, on -> prefs.edit().putBoolean("demo", on).apply() }
        })

        // ---- Story scene ----
        col.addView(section("12:30 scene"))
        col.addView(Switch(this).apply {
            text = "Show the scene every day"
            isChecked = prefs.getBoolean("story_on", true)
            setOnCheckedChangeListener { _, on -> prefs.edit().putBoolean("story_on", on).apply() }
        })
        col.addView(TextView(this).apply { text = "Scene time (AM/PM)"; textSize = 15f; setPadding(0, dp(8), 0, 0) })
        col.addView(TimePicker(this).apply {
            setIs24HourView(false)
            hour = prefs.getInt("story_h", 0)
            minute = prefs.getInt("story_m", 30)
            setOnTimeChangedListener { _, h, m -> prefs.edit().putInt("story_h", h).putInt("story_m", m).apply() }
        })
        col.addView(nameField("Man's name", "man_name", "Rahul"))
        col.addView(nameField("Girl's name", "girl_name", "S"))

        val colorNames = listOf("Red", "Crimson", "Pink", "Yellow", "White")
        val fc = Spinner(this)
        fc.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, colorNames)
        fc.setSelection(StorySettings.FLOWER_COLORS.indexOf(prefs.getInt("flower_color", StorySettings.FLOWER_COLORS[0])).coerceAtLeast(0))
        fc.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(a: AdapterView<*>?, v: View?, i: Int, id: Long) {
                prefs.edit().putInt("flower_color", StorySettings.FLOWER_COLORS[i]).apply()
            }
            override fun onNothingSelected(a: AdapterView<*>?) {}
        }
        col.addView(TextView(this).apply { text = "Flower colour"; textSize = 15f; setPadding(0, dp(8), 0, 0) })
        col.addView(fc)

        slider(col, "scene_len", "Scene length", 50) { "%.0f s".format(30 + it * 0.6f) }
        slider(col, "fig_size", "Figure size", 50) { "%.2fx".format(0.6f + it * 0.006f) }
        slider(col, "walk_speed", "Walk speed", 33) { "%.2fx".format(0.5f + it * 0.015f) }
        slider(col, "grain", "Film grain", 35) { "$it%" }
        slider(col, "vignette", "Dark edges", 45) { "$it%" }
        slider(col, "warmth", "Warm colours", 30) { "$it%" }

        val sil1 = Silhouette.load(resources, R.drawable.rahul)
        val sil2 = Silhouette.load(resources, R.drawable.girl)
        preview = ScenePreview(this, sil1, sil2)
        col.addView(preview, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(260)))
        col.addView(Button(this).apply {
            text = "Show now (preview)"
            setOnClickListener { preview.play(StorySettings(prefs)) }
        })
        col.addView(Button(this).apply {
            text = "Reset scene settings"
            setOnClickListener { resetScene() }
        })

        // ---- Wallpaper ----
        col.addView(section("Wallpaper"))
        col.addView(Button(this).apply {
            text = "Set wallpaper"
            setOnClickListener {
                val i = Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER)
                    .putExtra(WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT, ComponentName(this@MainActivity, SkylineService::class.java))
                try { startActivity(i) } catch (e: ActivityNotFoundException) {
                    startActivity(Intent(WallpaperManager.ACTION_LIVE_WALLPAPER_CHOOSER))
                }
            }
        })

        setContentView(ScrollView(this).apply { addView(col) })
        refresh()
    }

    private fun section(t: String) = TextView(this).apply {
        text = t
        textSize = 20f
        setPadding(0, dp(24), 0, 0)
    }

    private fun nameField(hint: String, key: String, def: String) = EditText(this).apply {
        this.hint = hint
        setText(prefs.getString(key, def))
        addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {
                val t = s?.toString()?.trim() ?: ""
                prefs.edit().putString(key, if (t.isEmpty()) def else t).apply()
            }
            override fun afterTextChanged(s: Editable?) {}
        })
    }

    private fun slider(root: LinearLayout, key: String, title: String, def: Int, show: (Int) -> String) {
        val tv = TextView(this)
        val bar = SeekBar(this).apply { max = 100; progress = prefs.getInt(key, def) }
        tv.text = "$title: ${show(bar.progress)}"
        bar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                tv.text = "$title: ${show(p)}"
                if (fromUser) prefs.edit().putInt(key, p).apply()
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })
        root.addView(tv)
        root.addView(bar)
    }

    private fun resetScene() {
        val e = prefs.edit()
        StorySettings.KEYS.forEach { e.remove(it) }
        e.apply()
        recreate()
    }

    override fun onRequestPermissionsResult(rc: Int, p: Array<out String>, r: IntArray) {
        if (r.isNotEmpty() && r[0] == PackageManager.PERMISSION_GRANTED) useLocation()
    }

    @Suppress("MissingPermission")
    private fun useLocation() {
        val lm = getSystemService(LOCATION_SERVICE) as LocationManager
        val loc = lm.getProviders(true).mapNotNull { lm.getLastKnownLocation(it) }.maxByOrNull { it.time }
        if (loc == null) Toast.makeText(this, "Location not found. Open Maps once, then try again, or choose a city.", Toast.LENGTH_LONG).show()
        else save(loc.latitude, loc.longitude)
    }

    private fun save(lat: Double, lon: Double) {
        prefs.edit().putFloat("lat", lat.toFloat()).putFloat("lon", lon.toFloat()).apply()
        refresh()
    }

    private fun refresh() {
        info.text = if (prefs.contains("lat")) "Location: %.2f, %.2f".format(prefs.getFloat("lat", 0f), prefs.getFloat("lon", 0f))
        else "Location: estimated from phone time zone"
    }
}

/** Plays the scene inside the app, so the scene can be checked without waiting for 12:30. */
class ScenePreview(ctx: Context, rahul: Bitmap, girl: Bitmap) : View(ctx) {
    private val scene = StoryScene(rahul, girl)
    private val look = ClassicLook()
    private var cfg = StorySettings(ctx.getSharedPreferences("scene", Context.MODE_PRIVATE))
    private val bg = Paint()
    private var running = false
    private var lastRt = 0L

    private val loop = object : Runnable {
        override fun run() {
            if (!running) return
            val rt = SystemClock.elapsedRealtime()
            val dt = if (lastRt == 0L) 0f else min(0.1f, (rt - lastRt) / 1000f)
            lastRt = rt
            scene.step(dt, rt, cfg)
            invalidate()
            if (scene.active) {
                postOnAnimation(this)
            } else {
                running = false
            }
        }
    }

    fun play(s: StorySettings) {
        cfg = s
        lastRt = 0L
        removeCallbacks(loop)
        scene.restart(SystemClock.elapsedRealtime())
        running = true
        postOnAnimation(loop)
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        look.resize(w.toFloat(), h.toFloat())
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        bg.shader = LinearGradient(0f, 0f, 0f, h, 0xFF07101F.toInt(), 0xFF1B2A4A.toInt(), Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, w, h, bg)
        scene.draw(c, w, h, 1f, cfg)
        look.draw(c, cfg)
    }

    override fun onDetachedFromWindow() {
        running = false
        removeCallbacks(loop)
        super.onDetachedFromWindow()
    }
}
