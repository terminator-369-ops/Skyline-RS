package com.skyline.wallpaper

import android.content.SharedPreferences
import android.content.res.Resources
import android.graphics.*
import java.util.Calendar
import java.util.Random
import kotlin.math.*

/** Story and look settings, stored in the "scene" SharedPreferences file. */
class StorySettings(p: SharedPreferences) {
    val enabled = p.getBoolean("story_on", true)
    val hour = p.getInt("story_h", 0)              // 0..23, default 12:30 AM
    val minute = p.getInt("story_m", 30)
    val manName = p.getString("man_name", "Rahul") ?: "Rahul"
    val girlName = p.getString("girl_name", "S") ?: "S"
    val flowerColor = p.getInt("flower_color", FLOWER_COLORS[0])
    val sceneSeconds = 30f + p.getInt("scene_len", 50) * 0.6f      // 30..90 s
    val figureScale = 0.6f + p.getInt("fig_size", 50) * 0.006f     // 0.6..1.2
    val walkSpeed = 0.5f + p.getInt("walk_speed", 33) * 0.015f     // 0.5..2.0
    val grain = p.getInt("grain", 35) / 100f
    val vignette = p.getInt("vignette", 45) / 100f
    val warmth = p.getInt("warmth", 30) / 100f

    companion object {
        val FLOWER_COLORS = intArrayOf(
            0xFFD32F2F.toInt(), 0xFF9B111E.toInt(), 0xFFE75480.toInt(), 0xFFFFC107.toInt(), 0xFFFFFFFF.toInt()
        )
        val KEYS = listOf(
            "story_on", "story_h", "story_m", "man_name", "girl_name", "flower_color",
            "scene_len", "fig_size", "walk_speed", "grain", "vignette", "warmth"
        )
    }
}

object StoryTrigger {
    /** If the phone wakes this long after the time or later, the scene does not play for that time. */
    const val CATCH_UP_MS = 3L * 60 * 60 * 1000

    /** The most recent moment of hour:minute that is not in the future. */
    fun latest(hour: Int, minute: Int, now: Long): Long {
        val cal = Calendar.getInstance()
        cal.timeInMillis = now
        cal.set(Calendar.HOUR_OF_DAY, hour)
        cal.set(Calendar.MINUTE, minute)
        cal.set(Calendar.SECOND, 0)
        cal.set(Calendar.MILLISECOND, 0)
        if (cal.timeInMillis > now) cal.add(Calendar.DAY_OF_MONTH, -1)
        return cal.timeInMillis
    }
}

object Silhouette {
    /** Black-on-white photo -> black cut-out (alpha = darkness), cropped to the figure. */
    fun load(res: Resources, id: Int): Bitmap {
        val src = BitmapFactory.decodeResource(res, id, BitmapFactory.Options().apply { inScaled = false })
        val w = src.width
        val h = src.height
        val px = IntArray(w * h)
        src.getPixels(px, 0, w, 0, 0, w, h)
        src.recycle()
        var x0 = w; var y0 = h; var x1 = -1; var y1 = -1
        for (y in 0 until h) for (x in 0 until w) {
            val c = px[y * w + x]
            val lum = (Color.red(c) + Color.green(c) + Color.blue(c)) / 3
            val a = ((250 - lum) * 255 / 190).coerceIn(0, 255)
            px[y * w + x] = Color.argb(a, 0, 0, 0)
            if (a > 10) {
                if (x < x0) x0 = x
                if (x > x1) x1 = x
                if (y < y0) y0 = y
                if (y > y1) y1 = y
            }
        }
        val cw = x1 - x0 + 1
        val ch = y1 - y0 + 1
        val out = IntArray(cw * ch) { i -> px[(y0 + i / cw) * w + x0 + i % cw] }
        return Bitmap.createBitmap(out, cw, ch, Bitmap.Config.ARGB_8888)
    }
}

/**
 * The 12:30 story. Rahul walks to the lamp, kneels, holds out a flower,
 * the girl takes it, they hug, she walks away and fades, he waits, then walks on.
 * Everything is driven by the clock, so frame drops never change the timing.
 */
class StoryScene(private val rahul: Bitmap, private val girl: Bitmap) {
    companion object {
        const val BASE = 50f            // scene length in base units (scaled by the length setting)
        const val BASE_WALK = 0.02f     // screen widths per second at walk speed 1.0
        const val GROUND = 0.80f        // sidewalk line, fraction of screen height
        const val FIG_H = 0.24f         // figure height, fraction of screen height
        const val LAMP = 0.62f          // lamp x, fraction of screen width
        const val SQUASH_Y = 0.28f      // kneel is a squashed standing silhouette until a kneel image is added
        const val SQUASH_X = 0.10f
        const val GIRL_IN = 0.95f
        const val GIRL_STAND = LAMP + 0.20f
        const val GIRL_HUG = LAMP + 0.13f
        const val GIRL_OUT = 1.05f
    }

    var active = false
        private set
    var walkX = -0.1f               // Rahul's x, fraction of screen width
        private set

    private var startRt = 0L
    private var walkStart = 0f
    private var u = 0f              // scene time in base units

    private val body = Paint(Paint.FILTER_BITMAP_FLAG)
    private val rim = Paint(Paint.FILTER_BITMAP_FLAG).apply {
        colorFilter = PorterDuffColorFilter(0xFFFFD27A.toInt(), PorterDuff.Mode.SRC_IN)
    }
    private val petal = Paint(Paint.ANTI_ALIAS_FLAG)
    private val centre = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFFFE082.toInt() }
    private val label = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFFFF3D6.toInt()
        textAlign = Paint.Align.CENTER
        setShadowLayer(6f, 0f, 0f, 0xCC000000.toInt())
    }
    private val road = Paint().apply { color = 0xAA161820.toInt() }
    private val curb = Paint().apply { color = 0x55FFE6B0 }
    private val dash = Paint().apply { color = 0x66FFFFFF }
    private val pole = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF1B1F2A.toInt() }
    private val bulb = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFFFECAA.toInt() }
    private val glow = Paint()
    private val rectF = RectF()

    /** Starts the scene now. Rahul keeps walking from where he is. */
    fun start(rt: Long) {
        startRt = rt
        walkStart = walkX
        u = 0f
        active = true
    }

    /** Preview: Rahul enters from the left and the whole scene plays. */
    fun restart(rt: Long) {
        walkX = -0.1f
        start(rt)
    }

    /** Call once per frame. dt = seconds since the last call, rt = elapsedRealtime in ms. */
    fun step(dt: Float, rt: Long, s: StorySettings) {
        if (active) {
            u = (rt - startRt) / 1000f / (s.sceneSeconds / BASE)
            if (u >= BASE) active = false
        }
        if (active && u < 13f) {
            walkX = walkStart + (LAMP - walkStart) * ease(u / 13f)
        } else if (active && u < 41f) {
            walkX = LAMP
        } else {
            walkX += dt * BASE_WALK * s.walkSpeed
            if (walkX > 1.15f) walkX -= 1.3f      // wraps while off-screen
        }
    }

    fun draw(c: Canvas, W: Float, H: Float, dark: Float, s: StorySettings) {
        val ground = H * GROUND
        val fig = H * FIG_H * s.figureScale
        val kneel = if (active) kneelAmount(u) else 0f
        val bob = abs(sin(walkX * 314f)) * H * 0.004f * (1f - kneel)   // bobs only while walking
        val rg = ground - bob
        val rx = walkX * W
        val rh = fig * (1f - SQUASH_Y * kneel)
        val rw = fig * aspect(rahul) * (1f + SQUASH_X * kneel)

        drawRoad(c, W, H, ground)
        drawLamp(c, W, H, ground, dark, if (active) glowBoost(u) else 0f)

        var gx = 0f
        var ga = 0f
        if (active) {
            gx = girlPos(u) * W
            ga = girlAlpha(u)
            if (ga > 0f) {
                drawFigure(c, girl, gx, ground, fig, 0f, ga, u > 30f)
                drawName(c, s.girlName, gx, ground - fig, H, ga)
            }
        }

        drawFigure(c, rahul, rx, rg, fig, kneel, 1f, true)
        drawName(c, s.manName, rx, rg - rh, H, 1f)

        if (!active) return

        // Flower: held out, then passed to her hand
        val bloom = ease(seg(u, 15f, 15.6f))
        val handX = rx + rw * 0.30f
        val handY = rg - rh * 0.45f
        val gHandX = gx - fig * aspect(girl) * 0.30f
        val gHandY = ground - fig * 0.45f
        val fx: Float
        val fy: Float
        if (u < 21f) {
            fx = handX; fy = handY
        } else if (u < 23f) {
            val t = ease(seg(u, 21f, 23f))
            fx = lerp(handX, gHandX, t); fy = lerp(handY, gHandY, t)
        } else {
            fx = gHandX; fy = gHandY
        }
        val fa = bloom * (if (u < 33f) 1f else ga)
        drawFlower(c, fx, fy, fig * 0.075f * bloom, s.flowerColor, fa)

        if (u in 25f..40f) drawPetals(c, (rx + gx) / 2f, ground, fig, u, s.flowerColor)
    }

    // ---------- timeline ----------
    private fun kneelAmount(u: Float) = ease(seg(u, 13f, 15f)) * (1f - ease(seg(u, 23f, 25f)))
    private fun glowBoost(u: Float) = 0.6f * ease(seg(u, 14f, 16f)) * (1f - ease(seg(u, 22f, 25f)))

    private fun girlPos(u: Float): Float = when {
        u < 19f -> GIRL_IN
        u < 23f -> lerp(GIRL_IN, GIRL_STAND, ease(seg(u, 19f, 23f)))
        u < 25f -> GIRL_STAND
        u < 30f -> lerp(GIRL_STAND, GIRL_HUG, ease(seg(u, 25f, 30f)))
        else -> lerp(GIRL_HUG, GIRL_OUT, ease(seg(u, 30f, 37f)))
    }

    private fun girlAlpha(u: Float): Float = when {
        u < 17f -> 0f
        u < 20f -> ease(seg(u, 17f, 20f))
        u < 33f -> 1f
        else -> 1f - ease(seg(u, 33f, 37f))
    }

    // ---------- drawing ----------
    private fun drawRoad(c: Canvas, W: Float, H: Float, ground: Float) {
        c.drawRect(0f, ground, W, H, road)
        c.drawRect(0f, ground - H * 0.002f, W, ground + H * 0.002f, curb)
        val y = H * 0.9f
        var x = 0f
        while (x < W) {
            c.drawRect(x, y - H * 0.003f, x + W * 0.06f, y + H * 0.003f, dash)
            x += W * 0.12f
        }
    }

    private fun drawLamp(c: Canvas, W: Float, H: Float, ground: Float, dark: Float, boost: Float) {
        val px = LAMP * W
        val top = ground - H * 0.36f
        val bulbX = px + W * 0.06f
        val bulbY = top + H * 0.01f
        c.drawRect(px - W * 0.005f, top, px + W * 0.005f, ground, pole)
        c.drawRect(px, top - H * 0.003f, bulbX, top + H * 0.003f, pole)
        val a = ((dark * 0.55f + boost * 0.6f).coerceIn(0f, 1f) * 255).toInt()
        if (a > 0) {
            glow.shader = RadialGradient(
                bulbX, bulbY, W * 0.45f,
                intArrayOf(Color.argb(a, 255, 200, 120), Color.argb(0, 255, 200, 120)),
                null, Shader.TileMode.CLAMP
            )
            c.drawCircle(bulbX, bulbY, W * 0.45f, glow)
        }
        c.drawCircle(bulbX, bulbY, W * 0.011f, bulb)
    }

    /** kneel: 0 = standing, 1 = crouched. Bottom stays on the ground. */
    private fun drawFigure(
        c: Canvas, bmp: Bitmap, cx: Float, ground: Float, fig: Float,
        kneel: Float, alpha: Float, flip: Boolean
    ) {
        if (alpha <= 0f) return
        val fh = fig * (1f - SQUASH_Y * kneel)
        val fw = fig * aspect(bmp) * (1f + SQUASH_X * kneel)
        val left = cx - fw / 2f
        val top = ground - fh
        c.save()
        if (flip) c.scale(-1f, 1f, cx, 0f)
        // thin warm rim light along the top edge, from the lamp
        rim.alpha = (alpha * 160).toInt()
        rectF.set(left, top - fh * 0.012f, left + fw, ground - fh * 0.012f)
        c.drawBitmap(bmp, null, rectF, rim)
        body.alpha = (alpha * 255).toInt()
        rectF.set(left, top, left + fw, ground)
        c.drawBitmap(bmp, null, rectF, body)
        c.restore()
    }

    private fun drawName(c: Canvas, text: String, cx: Float, headY: Float, H: Float, alpha: Float) {
        if (alpha <= 0f) return
        label.textSize = H * 0.022f
        label.alpha = (alpha * 255).toInt()
        c.drawText(text, cx, headY - H * 0.012f, label)
    }

    private fun drawFlower(c: Canvas, x: Float, y: Float, r: Float, color: Int, a: Float) {
        if (r <= 0f || a <= 0f) return
        val al = (a * 255).toInt().coerceIn(0, 255)
        petal.color = color
        petal.alpha = al
        for (i in 0 until 5) {
            val ang = Math.toRadians(i * 72.0 - 90.0)
            c.drawCircle(
                x + (cos(ang) * r * 0.55).toFloat(), y + (sin(ang) * r * 0.55).toFloat(),
                r * 0.45f, petal
            )
        }
        centre.alpha = al
        c.drawCircle(x, y, r * 0.3f, centre)
    }

    private fun drawPetals(c: Canvas, cx: Float, ground: Float, fig: Float, u: Float, color: Int) {
        petal.color = color
        for (i in 0 until 36) {
            val p = (u - (25f + i * 0.22f)) / 7f
            if (p < 0f || p > 1f) continue
            val h = sin(i * 12.9898) * 43758.5453
            val r01 = (h - floor(h)).toFloat()
            val x = cx + (r01 - 0.5f) * fig * 0.9f + sin(u * 1.5f + i) * fig * 0.06f
            val y = ground - fig * 1.05f + p * fig * 1.1f
            petal.alpha = ((1f - p) * 230f).toInt()
            c.drawCircle(x, y, fig * 0.014f, petal)
        }
    }

    // ---------- helpers ----------
    private fun aspect(b: Bitmap) = b.width.toFloat() / b.height
    private fun seg(x: Float, a: Float, b: Float) = ((x - a) / (b - a)).coerceIn(0f, 1f)
    private fun ease(t: Float): Float {
        val k = t.coerceIn(0f, 1f)
        return k * k * (3f - 2f * k)
    }
    private fun lerp(a: Float, b: Float, t: Float) = a + (b - a) * t
}

/** Classic film look over the whole wallpaper: grain, dark edges, warm colour. */
class ClassicLook {
    companion object {
        const val NOISE = 96
    }

    private var w = 1f
    private var h = 1f
    private var frame = 0
    private val rnd = Random(42)
    private val noise: Bitmap = Bitmap.createBitmap(
        IntArray(NOISE * NOISE) {
            val v = rnd.nextInt(256)
            Color.argb(rnd.nextInt(70), v, v, v)
        }, NOISE, NOISE, Bitmap.Config.ARGB_8888
    )
    private val grainShader = BitmapShader(noise, Shader.TileMode.REPEAT, Shader.TileMode.REPEAT)
    private val grainMatrix = Matrix()
    private val grainPaint = Paint().apply { shader = grainShader }
    private val warmPaint = Paint().apply { color = 0xFFFFA550.toInt() }
    private val vignettePaint = Paint()

    fun resize(width: Float, height: Float) {
        w = width
        h = height
        vignettePaint.shader = RadialGradient(
            w / 2f, h / 2f, max(w, h) * 0.75f,
            intArrayOf(0x00000000, 0x00000000, 0xFF000000.toInt()),
            floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP
        )
    }

    fun draw(c: Canvas, s: StorySettings) {
        frame++
        if (s.warmth > 0f) {
            warmPaint.alpha = (s.warmth * 80).toInt()
            c.drawRect(0f, 0f, w, h, warmPaint)
        }
        if (s.vignette > 0f && vignettePaint.shader != null) {
            vignettePaint.alpha = (s.vignette * 220).toInt()
            c.drawRect(0f, 0f, w, h, vignettePaint)
        }
        if (s.grain > 0f) {
            grainMatrix.setTranslate(((frame * 37) % NOISE).toFloat(), ((frame * 53) % NOISE).toFloat())
            grainShader.setLocalMatrix(grainMatrix)
            grainPaint.alpha = (s.grain * 255).toInt()
            c.drawRect(0f, 0f, w, h, grainPaint)
        }
    }
}
